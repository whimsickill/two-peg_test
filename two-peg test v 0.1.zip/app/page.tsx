import TwoPegTestApp from "@/components/TwoPegTestApp";

export default function Page() {
  return <TwoPegTestApp />;
}